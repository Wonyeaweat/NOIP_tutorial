#include<cstdio>
int main()
{//gg
	freopen("T3.in","r",stdin);
	freopen("T3.out","w",stdout);
	printf("2\n3\n5\n4\n");
	return 0;
}
