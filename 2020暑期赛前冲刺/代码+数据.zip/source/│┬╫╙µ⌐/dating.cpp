#include<iostream>
using namespace std;
int gcd(int x1,int x2){
	if(x1%x2==0)return x2;
	else return gcd(x2,x2%x1);
}
int main(){
	freopen("dating.in","r",stdin);
	freopen("dating.out","w",stdout);
	int a,b;
	long long x,y,ans=0;
	cin>>a>>b>>x>>y;
	int lcm;
	lcm=a*b/gcd(a,b);
	for(int i=x;i<=y;i++){
		if(i%lcm==0){
			ans++;
		}
	}
	cout<<ans<<endl;
}
