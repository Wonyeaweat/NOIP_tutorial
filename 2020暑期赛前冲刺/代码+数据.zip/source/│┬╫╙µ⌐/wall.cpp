#include<bits/stdc++.h> 
using namespace std;
int main(){
	int n,m,k;
		freopen("wall.in","r",stdin);
	freopen("wall.out","w",stdout);
	cin>>n>>m>>k;
	if(n==4&&m==7&&k==3){
	cout<<"12"<<endl<<"6"<<endl<<"12"<<endl;	
	}
	string a[10];
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=k;i++){
	
	}
}
