#include<bits/stdc++.h>
using namespace std;
void dfs(char** board,int i,int j,int n,int m,int ret){
	if(!(i>=0&&j>=0&&i<n&&j<m))
		ret++;
		return;
	if(board[i][j]=='.'){
		dfs(board,i-1,j);
		dfs(board,i+1,j);
		dfs(board,i,j-1);
		dfs(board,i,j+1);
	}		
}
int main(){
	freopen("wall.in","r",stdin);
	freopen("wall.out","w",stdout);
	char room[21][21];
	int count[100000][2];
	int n,m,k,a,b;
	int ret=0;
		cin>>n>>m>>k;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				filein>>room[i][j]; 
			}
		for(int i=0;i<k;i++){
			cin>>count[i][0]>>count[i][1];
		}
	}
	for(int i=0;i<k;i++){
		a=count[i][0];
		b=count[i][1];
		dfs(room,a,b,n,m,ret);
	}
	cout<<ret;
	return 0;
}
