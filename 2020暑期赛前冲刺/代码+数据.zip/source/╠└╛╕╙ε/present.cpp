/*
��			��			��			�� 
G+G=O
G+O=G(here
O+O=O
*/
#include<bits/stdc++.h>
 #include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
using namespace std;
bool cmp(int x, int y){
	return x>y;
}
int main(){
	freopen("present.in","r",stdin);
	freopen("present.out","w",stdout);
	int i,n,ret=0,temp1=-10000000,temp2=-10000000;
	long long ai[100010]={0};
		cin>>n;
		for(int i=0;i<n;i++){
			cin>>ai[i];
		}
	sort(ai,ai+n,cmp);
	for(int i=0;i<n&&ai[i]>0;i++){
		ret+=ai[i];
	}
	if(ret%2!=0){
		cout<<ret;
	}
	else{
		int j=i;
		while(j<n){
			if(ai[j]%2!=0){
				temp1=ret+ai[j];
				break;
			}
			j++;
		}
		i--;
		while(i>=0){
			if(ai[i]%2!=0){
				temp2=ret-ai[i];
				break;
			}
			i--;
		}
		if(temp1>temp2){
			cout<<temp1;
		}
		else{
			cout<<temp2;
		}
	}
	return 0;
}
