#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("dating.in","r",stdin);
	freopen("dating.out","w",stdout);
	long long a,b,x,y;
	int count=0;
	cin>>a>>b>>x>>y;
	for(int i=x;i<=y;i++){
		if(i%a==0&&i%b==0){
			count++;
		}
	}
	cout<<count<<endl;
	return 0;
}
