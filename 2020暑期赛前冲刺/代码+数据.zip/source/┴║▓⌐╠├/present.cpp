#include<iostream>
#include<cstdio>
#include<algorithm>
#include<stdlib.h>
#include<queue>
#include<math.h>
#include<string>
#include<cstring>
#include<iomanip>
#define f(i,a,b) for(int i=a;i<b;i++)
#define ff(i,a,b) for(int i=a;i<=b;i++)
#define r(i,a,b) for(int i=a;i>b;i--)
#define rr(i,a,b) for(int i=a;i>=b;i--)
#define inf 0x7fffffff
#define ll long long
using namespace std;
bool judge(int x){
	if(x<2) return false;
	for(int i=2;i*i<=x;i++)
		if(x%i==0) return false;
	return true;
}

//dij
//const int maxn =  1020;
//const int INF = 0x3f3f3f3f;
//const int inf = 0x3f;
//typedef long long ll;
//int n,m;

//int dis[maxn];          ///a������ľ���
//bool used[maxn];        ///��Ǹõ��Ƿ��Ѿ�ʹ��
//int pre[maxn];          ///���·������·��

//int map[maxn][maxn];
//void dijkstra(int a){
//    mem(used,0);
//   for(int i=1;i<=n;i++){
//        dis[i] = map[a][i];
//        pre[i] = (dis[i]==INF)?-1:a;
//    }
//    dis[a] = 0;
//    used[a] = true;
//    for(int i=1;i<=n;i++){
//        int Min = INF,Np = a;
//        for(int j=1;j<=n;j++)
//        if(!used[j] && dis[j] <Min){
//            Np = j;
//            Min = dis[j];
//        }
//        if(Np == a)
//            return;
//        used[Np] = true;
//        for(int j=1;j<=n;j++)
//            if(dis[j] > (dis[Np]+map[Np][j])){
//                dis[j] = dis[Np]+map[Np][j];
//                pre[j] = Np;
//            }
//    }
//}
//int main()
//{
//    int a,b,c;
//    while(cin >> n>>m){
//        For(i,m){
//            cin >> a >> b >> c;
//            map[a][b] = map[b][a] = min(map[a][b],c);
//        }
//        dijkstra(1);
//        cout << (dis[n]==INF?-1:dis[n]) << endl;            ///1->n�����·
//    }
//    return 0;
//}


//spfa
//void spfa(int s,int m)
//{
//  int i,k,ts=0,te=1;
//  Q[ts] = s;
//  dis[s] = 0;
//  while(ts<te)
//  {
//    k = Q[ts];
//    visit[k]=false; //�޸ĺ����ӵ� 2010.8.18 01:27
//    for(i=1;i<=m;i++)
//   {
//       if(g[k][i]>0 && dis[i] - g[k][i] > dis[k])
//       {
//          dis[i] = dis[k] + g[k][i];
//          if(!visit[i])
//          {
//             Q[te++] = i;
//             visit[i] = true;
//           }
//       }
//    }
//    ts++;
//  }
//}

//floyd
//int dist1[maxn][maxn],dist2[maxn][maxn],dist3[maxn][maxn],g[maxn][maxn];
//int n,m,q,s,t,x,y,z;
//void init(){
//    scanf("%d%d%d",&n,&m,&q);
//    for(int i=1;i<=n;i++){
//    	for(int j=1;j<=n;j++){
//            if(i==j)g[i][j]=0;
//            else g[i][j]=inf;
//        }
//	}
//	for(int i=1;i<=m;i++){
//        int x,y,z;
//        scanf("%d%d%d",&x,&y,&z);
//        g[x][y]=z;
 //       g[y][x]=z;
 //   }
//}
//void floyd(){
//    memcpy(dist1,g,sizeof(dist1));
 //   for(int k=1;k<=n;k++){
 //   	for(int i=1;i<=n;i++){
 //   		for(int j=1;j<=n;j++){
  //  			if(dist1[i][k]+dist1[k][j]<=dist1[i][j]){
 //      	            dist1[i][j]=dist1[i][k]+dist1[k][j];
 //               }
//			}
//		}
//	}
//}
//void floyd_max(){
//	memcpy(dist2,g,sizeof(dist2));
//	    for(int i=1;i<=n;i++){
 //   	for(int j=1;j<=n;j++){
 //   		if(dist2[i][j]==inf)dist2[i][j]=-inf;
//		}
//	}
 //   for(int k=1;k<=n;k++){
//    	for(int i=1;i<=n;i++){
//    		for(int j=1;j<=n;j++){
//    			int tmp=min(dist2[i][k],dist2[k][j]);
//                dist2[i][j]=max(dist2[i][j],tmp);
//			}
//		}
//	}
///}
//void floyd_min(){
//	memcpy(dist3,g,sizeof(dist3));
//    for(int k=1;k<=n;k++){
//    	for(int i=1;i<=n;i++){
//    		for(int j=1;j<=n;j++){
//    			int tmp=max(dist3[i][k],dist3[k][j]);
//                dist3[i][j]=min(dist3[i][j],tmp);
//			}
//		}
//	}
//}

//password 6H+0@1q-6K*nP/Nw=n1X

//int main(){
//    init();
//    floyd();
//    floyd_max();
//    floyd_min();
//    for(int i=1;i<=q;i++){
//        scanf("%d%d",&s,&t);
//        printf("%d %d %d\n",dist1[s][t],dist2[s][t],dist3[s][t]);
//    }
//    return 0;
//}
ll a[100005];
ll n,ans;
bool pd;
int main(){
	freopen("present.in","r",stdin);
	freopen("present.out","w",stdout);
	cin>>n;
	ff(i,1,n){
		cin>>a[i];
	}
	sort(a+1,a+n+1);
	rr(j,n,1){
	    rr(i,j-1,1){
		    ans=a[j]+a[i];
		    if(abs(ans)%2==1) break;
		    else continue;
	    }
	    if(abs(ans)%2==1) break;
	}
	cout<<ans;
	return 0;
}
