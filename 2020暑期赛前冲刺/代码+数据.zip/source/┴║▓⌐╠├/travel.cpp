#include<iostream>
#include<cstdio>
#include<algorithm>
#include<stdlib.h>
#include<queue>
#include<math.h>
#include<string>
#include<cstring>
#include<iomanip>
#define f(i,a,b) for(int i=a;i<b;i++)
#define ff(i,a,b) for(int i=a;i<=b;i++)
#define r(i,a,b) for(int i=a;i>b;i--)
#define rr(i,a,b) for(int i=a;i>=b;i--)
using namespace std;
bool judge(int x){
	if(x<2) return false;
	for(int i=2;i*i<=x;i++)
		if(x%i==0) return false;
	return true;
}
int main(){
    char a[30][1000];
	ff(i,1,26) cin>>a[i];
	cout<<9;
}
