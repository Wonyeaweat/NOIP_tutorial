#include<iostream>
using namespace std;
int main(){
	freopen("wall.in","r",stdin);
	freopen("wall.out","w",stdout);
	int n,m,k;
	char a[1001][1001];
	bool flag[1001][1001];
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>a[i][j];
			if(a[i][j]=='*'){
				flag[i][j]=1;
			}
			else{
				flag[i][j]=0;
			}
		}
	}
	while(k--){//���������ĸ�������ǽ 
		int x=0,y=0,ans=0;
		cin>>x>>y;
		while(1){
			if(flag[x+1][y]==1&&flag[x][y+1]==1&&flag[x-1][y]==1&&flag[x][y-1]==1)break;
			if(flag[x+1][y]==1) ans++;
			if(flag[x][y+1]==1) ans++;
			if(flag[x-1][y]==1) ans++;
			if(flag[x][y-1]==1) ans++;
			flag[x][y]=1;
			if(flag[x+1][y]==0&&flag[x+1][y]!=1){
				flag[x+1][y]=1;
				x++;
				if(flag[x+1][y]==1) ans++;
				if(flag[x][y+1]==1) ans++;
				if(flag[x-1][y]==1) ans++;
				if(flag[x][y-1]==1) ans++;
				if(ans==3) x--;
			}
			else if(flag[x][y+1]==0&&flag[x][y+1]!=1){
				flag[x][y+1]=1;
				y++;
				if(flag[x+1][y]==1) ans++;
				if(flag[x][y+1]==1) ans++;
				if(flag[x-1][y]==1) ans++;
				if(flag[x][y-1]==1) ans++;
				if(ans==3) y--;
			}
			else if(flag[x-1][y]==0&&flag[x-1][y]!=1){
				flag[x-1][y]=1;
				x--;
				if(flag[x+1][y]==1) ans++;
				if(flag[x][y+1]==1) ans++;
				if(flag[x-1][y]==1) ans++;
				if(flag[x][y-1]==1) ans++;
				if(ans==3) x++;
			}
			else if(flag[x][y-1]==0&&flag[x][y-1]!=1){
				flag[x][y-1]=1;
				y--;
				if(flag[x+1][y]==1) ans++;
				if(flag[x][y+1]==1) ans++;
				if(flag[x-1][y]==1) ans++;
				if(flag[x][y-1]==1) ans++;
				if(ans==3) y++;
			}
		}
		cout<<ans<<endl;
	}
}
