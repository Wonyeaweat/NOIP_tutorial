#include<iostream>
#include<algorithm>
using namespace std;
int main(){
	freopen("present.in","r",stdin);
	freopen("present.out","w",stdout);
	int n,a[100001],p=0;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	sort(a,a+n);
	for(int i=n;i>=1;i--){
		p=p+a[i];
		if(a[i+1]<0&&p%2!=0){
			break;
		}
		else if(a[i+1]<0&&p%2==0){
			if(-a[i+1]>a[i]){
				break;
			}
			else if(-a[i+1]<a[i]){
				p=p+a[i+1];
				continue;
			}
		}
		else if(i==1&&a[i]>0){
			if(p%2!=0){
				break;
			}
			else{
				p=p-a[i];
				break;
			}
		}
		else if(a[i+1]>0){
			if(p%2!=0){
				break;
			}
			else{
				p=p-a[i];
				break;
			}
		}
	}
	cout<<p;
	return 0;
}
