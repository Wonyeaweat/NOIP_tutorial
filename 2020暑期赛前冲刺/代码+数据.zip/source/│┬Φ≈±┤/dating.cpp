#include<iostream>
using namespace std;
int main(){
	freopen("dating.in","r",stdin);
	freopen("dating.out","w",stdout);
	int a,b,x,y,sum=0;
	cin>>a>>b>>x>>y;
	for(int i=x;i<=y;i++){
		for(int j=x;j<=y;j++){
			if(i%a==0&&j%b==0&&i==j){
				sum++;
			}
		}
	}
	cout<<sum;
	return 0;
}
