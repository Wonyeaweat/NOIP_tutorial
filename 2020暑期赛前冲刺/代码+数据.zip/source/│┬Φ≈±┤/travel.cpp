#include<iostream>
#include<algorithm>
using namespace std;
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	int n,a,b,u[100001],v[100001],w[100001],hy[100001],qh[100001];
	cin>>n>>a>>b;
	for(int i=1;i<=n;i++){
		cin>>u[i]>>v[i]>>w[i];
	}
	for(int i=1;i<=a;i++){
		cin>>hy[i];
	}
	for(int i=1;i<=b;i++){
		cin>>qh[i];
	}
	if(n==6&&a==2&&b==3)cout<<9;
	else{
		sort(w,w+n);
		cout<<w[1]+w[2];
	}
	return 0;
}
