#include <iostream>
#include <cstdio>
#include <queue>
#include <stack>
#include <vector>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
using namespace std;
int n,ans=-999999999;
int w[101010];
void dfs(int step,int sum){
	if(step==n+1){//cout<<sum<<endl;
		if(abs(sum)%2==1){
			ans=max(ans,sum);
		}
		return;
	}dfs(step+1,sum+w[step]);
	dfs(step+1,sum);
	return;
}
int main(){
	freopen("present.in","r",stdin);
	freopen("present.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)cin>>w[i];
	dfs(1,0);
	cout<<ans;
	return 0;
}
