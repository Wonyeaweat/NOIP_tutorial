#include <iostream>
#include <cstdio>
#include <queue>
#include <stack>
#include <vector>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
using namespace std;

int main(){
	freopen("dating.in","r",stdin);
	freopen("dating.out","w",stdout);
	int a,b,x,y;
	cin>>a>>b>>x>>y;
	int gbs;
	for(gbs=max(a,b);!(gbs%a==0&&gbs%b==0);gbs++){
		
	}
	int ans=y/gbs-x/gbs;
	if(x/gbs*gbs==x)ans++;
	cout<<ans<<endl;
	return 0;
}
