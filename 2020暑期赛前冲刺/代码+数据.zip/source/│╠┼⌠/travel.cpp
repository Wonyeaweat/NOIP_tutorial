#include <iostream>
#include <cstdio>
#include <queue>
#include <stack>
#include <vector>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
using namespace std;
int n,a,b,ds=-1;
int map[1010][1010];
int hy[101010],qh[101010];
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	while(1){
		cin>>n>>a>>b;
		for(int i=1;i<=1010;i++){
			for(int j=1;j<=1010;j++){
				if(i==j){
					map[i][j]=0;
					continue;
				}
				map[i][j]=999999999;
			}
		}
		for(int i=1;i<=n;i++){
			int u,v,w;
			cin>>u>>v>>w;
			map[u][v]=w;
			ds=max(ds,max(u,v));
		}
		for(int i=1;i<=a;i++)cin>>hy[i];
		for(int i=1;i<=b;i++)cin>>qh[i];
		for(int k=1;k<=ds;k++){
			for(int i=1;i<=ds;i++){
				for(int j=1;j<=ds;j++){
					map[i][j]=min(map[i][j],map[i][k]+map[k][j]);
				}
			}
		}
		int ans=999999999;
		for(int i=1;i<=a;i++){
			for(int j=1;j<=b;j++){
				ans=min(ans,map[hy[i]][qh[j]]);
			}
		}cout<<ans;
	}
	return 0;
}
