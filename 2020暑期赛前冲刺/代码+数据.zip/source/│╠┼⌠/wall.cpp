#include <iostream>
#include <cstdio>
#include <queue>
#include <stack>
#include <vector>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
using namespace std;
int n,m,k;
char a[1010][1010];
bool b[1010][1010];
int v[1010][1010];
int ans;
void dfs(int x,int y){
	b[x][y]=true;
	if(x+1<=n&&a[x+1][y]=='*')ans++;
	if(x-1>=1&&a[x-1][y]=='*')ans++;
	if(y+1<=m&&a[x][y+1]=='*')ans++;
	if(y-1>=1&&a[x][y-1]=='*')ans++;
	if(x+1<=n && a[x+1][y]=='.' && b[x+1][y]==false){
		dfs(x+1,y);
	}
	if(x-1>=1 && a[x-1][y]=='.' && b[x-1][y]==false){
		dfs(x-1,y);
	}
	if(y+1<=m && a[x][y+1]=='.' && b[x][y+1]==false){
		dfs(x,y+1);
	}
	if(y-1>=1 && a[x][y-1]=='.' && b[x][y-1]==false){
		dfs(x,y-1);
	}
	return;
}
void bfs(int x,int y){
	queue<int> qx,qy;
	qx.push(x);qy.push(y);
	b[x][y]=true;
	while(!qx.empty()){
		//cout<<ans<<endl;
		int i=qx.front(),j=qy.front();
		qx.pop();qy.pop();
		if(i+1<=n&&a[i+1][j]=='*')ans++;
		if(i-1>=1&&a[i-1][j]=='*')ans++;
		if(j+1<=m&&a[i][j+1]=='*')ans++;
		if(j-1>=1&&a[i][j-1]=='*')ans++;
		if(i+1<=n && a[i+1][j]=='.' && b[i+1][j]==false){
			qx.push(i+1);qy.push(j);
			b[i+1][j]=true;
		}
		if(i-1>=1 && a[i-1][j]=='.' && b[i-1][j]==false){
			qx.push(i-1);qy.push(j);
			b[i-1][j]=true;
		}
		if(j+1<=m && a[i][j+1]=='.' && b[i][j+1]==false){
			qx.push(i);qy.push(j+1);
			b[i][j+1]=true;
		}
		if(j-1>=1 && a[i][j-1]=='.' && b[i][j-1]==false){
			qx.push(i);qy.push(j+1);
			b[i][j-1]=true;
		}
	}
	return;
}
int main(){
	freopen("wall.in","r",stdin);
	freopen("wall.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>a[i][j];
			v[i][j]=-1;
		}
	}
	while(k--){
		int x,y;
		//cin>>x>>y;
		scanf("%d%d",&x,&y);
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(b[i][j])v[i][j]=ans;
				b[i][j]=false;
			}
		}ans=0;
		if(v[x][y]!=-1){
			printf("%d\n",v[x][y]);
			//cout<<"qwq"<<endl;
			continue;
		}
		bfs(x,y);
		printf("%d\n",ans);
	}
	return 0;
}
