#include<bits/stdc++.h>
using namespace std;
typedef pair<int, int> P;
char Map[1005][1005];
int n, m, ans, cnt;
int x, y;
int dx[4] = {1, 0, -1, 0}, dy[4] = {0, 1, 0, -1};
int vis[1005][1005];
int num[1000025];
void bfs()
{
    int i, j;
    queue<P> q;
    q.push(P(x, y));
    cnt++;
    vis[x][y] = cnt;
    ans = 0;
    while (q.size())
    {
        P temp = q.front();
        q.pop();
        ans += 4;
        for (i=0; i < 4; ++i)
        {
            int nx = temp.first + dx[i];
            int ny = temp.second + dy[i];
            if (nx >= 0 && nx < n && ny >= 0 && ny < m)
            {
                if(Map[nx][ny] == '.')
                {
                    ans--;
                    if(!vis[nx][ny])
                    {
                        q.push(P(nx, ny));
                        vis[nx][ny] = cnt;
                    }
                }
            }
            else
                ans--;
        }
    }
    num[cnt] = ans;
    cout << ans << endl;
}

int main()
{
	freopen("wall.in","r",stdin);
	freopen("wall.out","w",stdout);
	
    int i, j, k;
    cin >> n >> m >> k;
    for (i = 0; i < n; ++i)
        cin >> Map[i];
    memset(num, -1, sizeof(num));
    memset(vis, 0, sizeof(vis));
    cnt = 0;
    while (k--)
    {
        cin >> x >> y;
        x--, y--;
        if (vis[x][y] == 0)
            bfs();
        else
            cout << num[vis[x][y]] << endl;
    }
    return 0;
}
