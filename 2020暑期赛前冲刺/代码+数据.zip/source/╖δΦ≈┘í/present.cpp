#include<bits/stdc++.h>
using namespace std;
int a[100001];
int main()
{
	freopen("present.in","r",stdin);
	freopen("present.out","w",stdout);
	int n;
	cin>>n;
	int ans;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		sort(a+1,a+n+1);
		if(a[i]>=0)
		{
			ans+=a[i];
		}
		else if(a[i]<0&&a[i]==a[1])
		{
			ans+a[1]==ans;
		}
	}
	if(ans%2==0)
	{
		return ans;
	}
	else
	{
		cout<<ans;
	}
	return 0;
}

