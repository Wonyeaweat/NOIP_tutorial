#include<bits/stdc++.h>
using namespace std;
int gcd(int a,int b)
{
	if(a%b==0)
	{
		return b;
	}
	else
	{
		return gcd(b,a%b);
	}
}
int main()
{
	freopen("dating.in","r",stdin);
	freopen("dating.out","w",stdout);
	int a,b,x,y;
	int c;
	int d;
	cin>>a>>b>>x>>y;
	for(int i=x;i<=y;i++)
	{
		c=a*b/gcd(a,b);
		if(y%c==0)
		{
			if(c>=x)
			{
				d=y/c;
			}
			else
			{
				d=y/c-1;
			}
		}
		else
		{
			if(c>=x)
			{
				d=y/c;
			}
			else
			{
				d=y/c-1;
			}
		}
	 } 
	 cout<<d<<endl;
   return 0;
}

