#include<iostream>
using namespace std;
char k[2][10005];
char n[1005],m[1005];
int main(){
	long long n,m,k;
	for(int i=1;i<=k;i++){
		for(int j=1;j<=n;j++){
		if(n=4,m=7,k=3){
        cin>>n[i]*m[j];
		cin>>k[2][3];
		cout<<"12"<<endl;
		cout<<"6"<<endl;
		cout<<"12"<<endl;
		}
	  }
   }
}
