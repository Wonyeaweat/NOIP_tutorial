#include<iostream>
#include<cstring>
//freopen("present.in","4 -2 2 -3 1",stdin);
//freopen("present.out","3",stdout);  
//freopen("present.in","3 2 -5 -3",stdin);
//freopen("present.out","-1",stdout);  
using namespace std;
string a;
int main(){
	
	freopen("present.in","r",stdin);
    freopen("present.out","w",stdout);  
	long long n,m,k,x,y;
    for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){			
		    scanf("%d",n);	
			scanf("%d",a[n]);
			if(x+k>i+j,x+k!=2*y){
				printf("%d",x+k);
			}
			else{
				if(x+i>k+j, x+i!=2*y){
					printf("%d",x+i);
				}
				else{
					if(k+j!=2*y){
						printf("%d",k+j);
					}
					else{
						if(i+j!=2*y){
							printf("%d",i+j);
						}
					}
				}
			}
		}
	}
}
		    
