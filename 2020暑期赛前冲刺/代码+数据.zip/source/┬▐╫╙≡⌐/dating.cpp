#include<iostream>
using namespace std;
int main(){
    freopen("dating.in","r",stdin);
    freopen("dating.out","w",stdout);  
	long long a,b,x,y;
	cin>>a>>b>>x>>y;
	cout<<(y-x)/(a*b)+1;
	return 0;
} 
