//������
#include <iostream>
#include <iostream>
#include <cmath>
#include <iomanip>
#include <algorithm>
#include <cstring>
#include <cstdio>
//#include <windows.h>
//--------------------//
//cout << fixed << setprecision(2) <<;
using namespace std;

char map [1010][1010],mapn[1010][1010];
int num = 0;

int find (int x,int y){
    if(mapn[x - 1][y] == '.'){
        mapn[x][y] = '#';
		find(x - 1,y);
    }
    if(mapn[x + 1][y] == '.'){
		mapn[x][y] = '#';
        find(x + 1,y);
    }
    if(mapn[x][y - 1] == '.'){
        mapn[x][y] = '#';
		find(x,y - 1);
    }
    if(mapn[x][y + 1] == '.'){
        mapn[x][y] = '#';
		find(x,y + 1);
    }
    if(mapn[x - 1][y] == '*'){
        num++;
    }
    if(mapn[x + 1][y] == '*'){
        num++;
    }
    if(mapn[x][y - 1] == '*'){
        num++;
    }
    if(mapn[x][y + 1] == '*'){
        num++;
    }
    return num;
}

int main() {
    freopen("wall.in","r",stdin);
    int n,m,k;
    cin >> n >> m >> k;
    for(int i = 1;i <= n;i++){
        for(int j = 1;j <= m;j++){
            cin >> map[i][j];
            mapn[i][j] = map[i][j];
        }
    }          
    int x[10100],y[10100];
    for(int i = 0;i < k;i++){
        cin >> x[i] >> y[i];
    }  
    freopen("wall.out","w",stdout);
    for(int i = 0;i < k;i++){
    	num = 0; 
        for(int a = 1;a <= n;a++){
            for(int b = 1;b <= m;b++){
                mapn[a][b] = map[a][b];
            }
        }
        cout << find(x[i],y[i]) << endl;
    }            
    return 0;
}
