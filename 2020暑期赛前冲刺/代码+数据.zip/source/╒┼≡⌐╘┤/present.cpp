//�ڶ���
#include <iostream>
#include <iostream>
#include <cmath>
#include <iomanip>
#include <algorithm>
#include <cstring>
#include <cstdio>
//#include <windows.h>
//--------------------//
//cout << fixed << setprecision(2) <<;
using namespace std;
int main() {
    freopen("present.in","r",stdin);  
    int n,present[100100];//max�洢�𰸣����ֵ��,numΪ���������洢���ڵ�ֵ
    long long max,num = 0;
    cin >> n;
    for(int i = 0;i < n;i++){
        cin >> present[i];
    }
    sort(present,present + n);
    max = present[0];
    for(int i = n - 1;i >= 0;i--){
        num += present[i];
        if(num & 1){
            if(max < num){
                max = num;
            }
        }
    }
    freopen("present.out","w",stdout);
    cout << max;
    return 0;
}

