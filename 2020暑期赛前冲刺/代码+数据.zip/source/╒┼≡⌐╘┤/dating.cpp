//��һ��
#include <iostream>
#include <iostream>
#include <cmath>
#include <iomanip>
#include <algorithm>
#include <cstring>
#include <cstdio>
//#include <windows.h>
//--------------------//
//cout << fixed << setprecision(2) <<;
using namespace std;
int main() {
    freopen("dating.in","r",stdin);
    int a,b,x,y,num,ans = 0;
    cin >> a >> b >> x >> y;
    //����С������
    if(a == 0 || b == 0){
    	freopen("dating.out","w",stdout);
    	cout << "0";
    	return 0;
	}else if(b % a == 0 || a % b == 0){
        num = max(a,b);
    }else{
        num = a * b;
    }
    int num1 = x;
    if(x % num == 0 && num >= x){
        num1 = 0;
    }else if(x % num == 0 && num < x){
        num1 = x;
    }else{
        num1 -= (x % num);
    }
    for(int i = num + num1;i >= x && i <= y;i += num){
        ans++;
    }
    freopen("dating.out","w",stdout);
    cout << ans;
    return 0;
}
