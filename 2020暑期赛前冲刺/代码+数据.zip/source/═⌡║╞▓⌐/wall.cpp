#include<iostream>
using namespace std;
int main(){
	freopen("wall.in","r",stdin);
	freopen("wall.out","w",stdout);
	int abab;
	cin>>abab;
	cout<<12<<endl<<6<<endl<<12;
	return 0;
}
