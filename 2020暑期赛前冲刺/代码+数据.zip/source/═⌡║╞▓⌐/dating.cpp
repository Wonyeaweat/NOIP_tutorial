#include<iostream>
#include<algorithm>
#include<cmath>
#include<vector>
#include<stdio.h>
using namespace std;

long long a,b,x,y,cnt;

int main(){
	freopen("dating.in","r",stdin);
	freopen("dating.out","w",stdout);
	cin>>a>>b>>x>>y;
	for(int i=x;i<=y;i++){
		if(i%a==0&&i%b==0){
			cnt++;
		}
	}
	cout<<cnt;
	return 0;
}
