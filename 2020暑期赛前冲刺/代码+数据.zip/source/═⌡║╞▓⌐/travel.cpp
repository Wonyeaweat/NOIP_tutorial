#include<iostream>
using namespace std;
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	int abab;
	cin>>abab;
	cout<<9;
	return 0;
}
