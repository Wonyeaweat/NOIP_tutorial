#include<iostream>
#include<algorithm>
#include<cmath>
#include<vector>
#include<stdio.h>
using namespace std;

long long n,az[10010],cnt=-1000000,temp;
//4
//-2 2 -3 1 
int main(){
	freopen("present.in","r",stdin);
	freopen("present.out","w",stdout);
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>az[i];
	}
	sort(az,az+n);
	for(int i=n-1;i>=0;i--){
//		if(az[i]<=-
		if(cnt<cnt+az[i]){
//			cout<<i; 
			if(i==n-1){
				cnt=az[i];
			}else{
				cnt+=az[i];
			}
		}else{
			if(cnt%2==0){
				for(int j=i;j<n;j++){
					temp=cnt;
					temp-=az[j];
					if(cnt%2==1){
						cout<<temp;
						return 0;
					} 
				}
				cnt+=az[i];
			}
		}
	}
	cout<<cnt;
	return 0;
}

