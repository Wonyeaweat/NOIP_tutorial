#include<bits/stdc++.h>
using namespace std;

const int maxt = 1e4;

const int maxab = 400;
set<pair<int,int> >s;
int d[100010];
int st[100010];
int Randint(int Max){
	int ret = (rand()&0x3)<<30 | rand()<<15 | rand();
	return 1+(abs(ret))%(Max-1);
}
void generate(){
	memset(d,0,sizeof(d));
	memset(st,0,sizeof(st));
    int n,m,T,a,b;
    
	s.clear();
    //printf("%d %d\n", n,m); // n�� m�� 
    a=maxab+Randint(maxab);
    b=maxab+Randint(maxab);
    
    n = a+b+Randint(100*(a+b));
    m = 2*n+Randint(n);
    printf("%d %d %d\n",m,a,b);// m�� a����㣬b���յ� 
    
    
    d[1] = 0;
    for(int i = 2;i <= n;++i){
    	int u = i;
    	int l = max(i - 5,1), r = i - 1;
    	int v = (Randint(n) % (r - l + 1)) + l;
    	d[u] = d[v] + 1;
    	int t = Randint(maxt);
    	s.insert(make_pair(u,v));
    	s.insert(make_pair(v,u));
    	if(t==0) t++;
    	printf("%d %d %d\n", u,v,t);
   	}
    for(int i = 1;i <= m-n+1 ;++i){
    	int u = Randint(n);
    	int v = Randint(n);
    	if((s.find(make_pair(u,v)) != s.end() )|| (u == v)) {i--;continue;}
    	s.insert(make_pair(u,v));
    	s.insert(make_pair(v,u));
    	int l = abs(d[u] - d[v]), r = l + 5;
    	int t = (Randint(n) % (r - l + 1)) + l;
    	if(t==0) t++;
    	printf("%d %d %d\n", u,v,t);
    } 
    
	while(a){
		int out = Randint(n);
		if(st[out]==0) {printf("%d ",out);st[out]=1;a--;}	
	}
	printf("\n");
	while(b){
		int out = Randint(n);
		if(st[out]==0) {printf("%d ",out);st[out]=1;b--;}	
	}
	printf("\n");
}

int main(){
	srand(time(NULL));
	freopen("10.in","w",stdout);
	generate();
	generate();
	return 0;
}
