#include <bits/stdc++.h>
using namespace std;
const int N = 100100;
int t[N],Sta,End;
void makeGraph(int n)
{
	Sta = End = 1+rand()%n; 
	while(End==Sta){
		End = 1+rand()%n; 
	}
    for (int i=1;i<=n;i++) t[i]=i;
    random_shuffle(t+1,t+n+1);
    for (int i=1;i<=n;i++) if (t[i]==Sta) {swap(t[i],t[1]);break;}

    int i;
    for (i=1;i<n;i++)
    {
        printf("%d -> %d",t[i],t[i+1]);
        if (t[i+1]==End) break;
    }

    int k;
    for (i++;i<n;i++)
    {
        k=rand()&1;
        if (!k)
            printf("%d -> %d\n",t[i],t[rand()%(i-1)+1]);
        else printf("%d -> %d\n",t[rand()%(i-1)+1],t[i]);
    }
}
int main() {
	freopen("2.in","w",stdout); 
	srand ( time ( NULL ) ) ;
	int n=rand() %10;
	cout<<n<<endl;
	makeGraph(n);
	return 0;
}
