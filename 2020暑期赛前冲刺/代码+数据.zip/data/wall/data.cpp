#include <bits/stdc++.h>
using namespace std;
int rand_32()
{
	return (rand()&0x3)<<30 | rand()<<15 | rand();
}
int Map[1010][1010];
int main() {
	freopen("10.in","w",stdout); 
	srand(time(NULL));
	int n=800+abs(rand_32())%200;
	int m=800+abs(rand_32())%200;
	int k=80000+abs(rand_32())%20000;
	int p=50;
	cout<<n<<' '<<m<<' '<<k<<endl;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(i==1||j==1||i==n||j==m) cout<<"*";
			else{
				int t=rand()%100;
				if(i==2 || i==n-1 || j==2 || j==m-1) p=75;
				else{
					p=90;
					if(Map[i-1][j] == 0 && Map[i][j-1] == 1) p=5;
					if(Map[i-1][j] == 1 && Map[i][j-1] == 0) p=5;
					if(Map[i-1][j-1] == 0) p+=50;
					
				}
				if(t>p) cout<<"*";
				else {
					cout<<".";
					Map[i][j]=1;
				}
			} 
		}
		cout<<endl;
	}
	
	int tmp=0;
	while(tmp<k){
		int x=2+rand()%(n-2);
		int y=2+rand()%(m-2);
		if(Map[x][y]==1) {cout<<x<<' '<<y<<endl;tmp++;}
	}
	return 0;
}

