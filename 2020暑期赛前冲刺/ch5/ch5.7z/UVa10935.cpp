/*

�������ݼ�С��ģ�⼴�ɡ�
ʹ�ö��� queue ģ�����ƹ��̡�
ע�⵱ n=1 ʱ��������������� 

*/ 

#include <iostream>
#include <queue>
#include <cstdio>

using namespace std;

int main() {
    int  t, n;
    queue<int> q;
    while (scanf("%d", &n) && n) {
        printf("Discarded cards:");
        for (int i = 1; i <= n; i++)
            q.push(i);
        if (n == 1) 
			puts("");
        else
            while (1) {
                t = q.front();
                q.pop();
                if (q.size() == 1) {
                    printf(" %d\n", t);
                    break;
                }
                else
                    printf(" %d,", t);
                t = q.front();
                q.pop();
                q.push(t);
            }
        printf("Remaining card: %d\n", q.front());
        q.pop();
    }
    return 0;
}
