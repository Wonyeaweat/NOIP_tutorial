/*

string::npos ��һ��������������ʾ�����ڵ�λ�ã�ȡֵ��ʵ�־�����һ����-1��
��Ҫ˼· ģ��
��ÿ�о��Ӽ�¼��Ȼ��ѵ�����ȡ������
�ҵ�ʱ��ֻ��Ҫ����һ�δ��ڻ��߲�����������ʣ�Ȼ�������н����ж�������ɡ�

*/

#include<iostream>
#include<cstdio>
#include<cstring>
#include<map>
#include<vector>
#include<sstream>
using namespace std;
map<string, vector<int> > s;
string doc[1505];
int limit[105];
bool print[1505];
int main() {
    int n, m;
    scanf("%d", &m);
    getchar();
    int j = 0;
    limit[0] = 0;
    for (int i = 1; i <= m; i++) {
        while (getline(cin, doc[j]) && doc[j] != "**********") {
            string a;
            for (int k = 0; k < doc[j].length(); k++) {
                if (isalpha(doc[j][k])) a += tolower(doc[j][k]);
                else a += ' ';
            }
            stringstream ss(a);
            string word;
            while (ss >> word)
                s[word].push_back(j);
            j++;
        }
        limit[i] = j++;
    }
    scanf("%d", &n);
    getchar();
    for (int i = 0; i < n; i++) {
        memset(print, 0, sizeof(print));
        string a, b;
        getline(cin, a);
        if (a.find("AND") != string::npos) {
            string c, d;
            int num1[1505] = { 0 }, num2[1505] = { 0 };
            int e = a.find("AND");
            c = a.substr(0, e - 1);
            d = a.substr(e + 4);
            for (int j = 0; j < s[c].size(); j++)
                num1[s[c][j]] = 1;
            for (int j = 0; j < s[d].size(); j++)
                num2[s[d][j]] = 1;
            for (int j = 0; j < m; j++) {
                bool hasa = false, hasb = false;
                for (int k = limit[j]; k < limit[j + 1]; k++)
                    if (num1[k]) hasa = 1;
                for (int k = limit[j]; k < limit[j + 1]; k++)
                    if (num2[k]) hasb = 1;
                if (!(hasb && hasa))continue;
                for (int k = limit[j]; k < limit[j + 1]; k++)
                    print[k] = (num1[k] || num2[k]);
            }
        }
        else if (a.find("OR") != string::npos) {
            stringstream ss(a);
            while (ss >> b)
                for (int j = 0; j < s[b].size(); j++)
                    print[s[b][j]] = 1;
        }
        else if (a.find("NOT") != string::npos) {
            b = a.substr(4);
            int num[1505] = { 0 };
            int N = 1;
            for (int j = 0; j < s[b].size(); j++)
                num[s[b][j]] = 1;
            for (int j = 1; j <= m; j++) {
                bool logo = true;
                for (int k = limit[j - 1]; k < limit[j]; k++)
                    if (num[k]) {
                        logo = false;
                        break;
                    }
                for (int k = limit[j - 1]; k < limit[j]; k++)
                    print[k] = logo;
            }
        }
        else {
            for (int j = 0; j < s[a].size(); j++)
                print[s[a][j]] = 1;
        }
        bool hasout = 0, needout = 0;
        for (int j = 1; j <= m; j++) {
            if (hasout) needout = true;
            hasout = false;
            for (int k = j == 1 ? 0 : limit[j - 1] + 1; k < limit[j]; k++)
                if (print[k]) {
                    if (needout) {
                        cout << "----------\n";
                        needout = false;
                    }
                    cout << doc[k] << endl;
                    hasout = true;
                }
        }
        if (!(needout || hasout))
            cout << "Sorry, I found nothing.\n";
        cout << "==========" << endl;
    }
}
