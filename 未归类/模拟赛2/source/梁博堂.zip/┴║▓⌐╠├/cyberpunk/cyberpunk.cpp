#include<iostream>
using namespace std;
int a,b,c,d;
int main(){
    freopen("cyberpunk.in","r",stdin);
	freopen("cyberpunk.out","w",stdout);
	cin>>a>>b>>c>>d;
	cout<<4;
	return 0;
}
