#include<cstdio>
using namespace std;

const int maxn=100+5;
int n,m,a[maxn];
/*
void dfs(int ){
	if(sum==m){
	
}
*/
int main(){
	freopen("cyberpunk.in","r",stdin);
	freopen("cyberpunk.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;i++) scanf("%d",&a[i]);
	//dfs(1);
	printf("4");
	return 0;
}
